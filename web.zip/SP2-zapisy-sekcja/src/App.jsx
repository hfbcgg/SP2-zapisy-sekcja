import { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.css'


function App() {
  const sekcje = ["Piłka nożna", "Szachy", "Robotyka", "Pływanie"]
  const [imieNazwisko, setImieNazwisko] = useState('') 
  const [nrSekcji, setNrSekcji] = useState('') 
  const handleZapisz = (e) => {
    e.preventDefault();
    console.log(imieNazwisko);
    console.log(nrSekcji);
  }

  const index = Number(nrSekcji-1);
  if (index >=0 && index<sekcje.length) {
    console.log(sekcje[index]);
  } else {
    console.log("Nieprawidłowy numer sekcji");
  }




  return (
    <div className="mb-3">
      <h2 className="sekcje">Liczba sekcji: {sekcje.length}</h2>
      <ol>
        {sekcje.map((sekcje, index)=>
        (<li key={index}>{sekcje}</li>))}
      </ol>





<form onSubmit={handleZapisz}>
  <div className="mb-3">
    <label htmlFor="imieNazwisko" className="form-label">Imię i nazwisko:</label>
    <input type="text" className="form-control" id="imieNazwisko" value={imieNazwisko} onChange={(e)=>setImieNazwisko(e.target.value)}/>
  </div>
  <div className="mb-3">
    <label htmlFor="numerSekcji" className="form-label">Numer sekcji:</label>
    <input type="number" className="form-control" id="numerSekcji" value={nrSekcji} onChange={(e)=>setNrSekcji(e.target.value)}/>
  </div>
  <button type="submit" className="btn btn-primary">Zapisz</button>
</form>

    </div>
  )
}

export default App
